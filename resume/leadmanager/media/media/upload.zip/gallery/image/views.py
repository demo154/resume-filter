from django.shortcuts import render
from .models import Image
from .forms import ImageUpload 
from . import templates
import os


# Create your views here.
def image_upload(request):
    images = Image.objects.all()
    if request.method == 'POST':    
        form = ImageUpload(request.POST, request.FILES)   
        if form.is_valid():
            # name = request.FILES[filename].name
            form.save()
            return render(request,'base.html',{'form': form})
    else:
        form = ImageUpload()
    return render(request, 'index.html', {'form': form})


# def get_filenam():
#     file = os.environ("")
#     AWS_file_Path = ""
#     Aws_URL = Aw



# def Detail_Data(request):
#     detail = Details.objects.all()
#     if request.method == 'POST':
#         form = DetailData(request.POST,request.Details)
#         if form.is_valid():
#             form.save()
#             return render(request,'home.html',{'form': form})
#     else:
#         form = DetailData()
#     return render(request, 'index.html', {'form': form})