from django.db import models
import os
# Create your models here.
class Image(models.Model):
    file = models.FileField()
    uploaded_at =  models.DateTimeField(auto_now_add=True)
    
    def filename(self):
        return os.path.basename(self.file.name)
# class Details(models.Model):
#     name = models.CharField(max_length= 20)
#     Email = models.EmailField(unique=True,null=False)
#     mobile = models.BigIntegerField(unique=True,null=False)
