from django import forms
from .models import Image
class ImageUpload(forms.ModelForm):
    class Meta:
        model = Image
        fields = ('file',)
        def save(self):
            image = super(ImageUpload, self).save()
            return image

# class DetailData(forms.ModelForm):
#     class Meta:
#         model = Details
#         fields =  ('name','Email','mobile' ,) 
#         def save(self):
#             details = super(DetailData, self).save()
#             return details